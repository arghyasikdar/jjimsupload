"""
Comprehensive Transfer Learning Example
=======================================
Demonstrates all transfer learning techniques in a complete pipeline.
"""

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
import numpy as np
import matplotlib.pyplot as plt
from typing import Dict, List

# Import our modules
from transfer_learning_cv import TransferLearningModel
from advanced_transfer_learning import (
    DiscriminativeLearningRate,
    GradualUnfreezing,
    DomainAdaptation,
    KnowledgeDistillation,
    learning_rate_finder
)


class ComprehensiveTransferLearning:
    """
    Complete transfer learning pipeline with all techniques.
    """
    
    def __init__(
        self,
        model_name: str = 'resnet50',
        num_classes: int = 10,
        use_discriminative_lr: bool = True,
        use_gradual_unfreezing: bool = True,
        use_domain_adaptation: bool = False
    ):
        self.model_name = model_name
        self.num_classes = num_classes
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        
        # Initialize model
        self.tl_model = TransferLearningModel(
            model_name=model_name,
            num_classes=num_classes,
            pretrained=True,
            freeze_base=True  # Start frozen
        )
        
        self.use_discriminative_lr = use_discriminative_lr
        self.use_gradual_unfreezing = use_gradual_unfreezing
        self.use_domain_adaptation = use_domain_adaptation
        
        # Gradual unfreezing scheduler
        if use_gradual_unfreezing:
            self.unfreezing_scheduler = GradualUnfreezing(
                self.tl_model.model,
                total_epochs=20
            )
    
    def setup_optimizer(self, base_lr: float = 0.001) -> optim.Optimizer:
        """Setup optimizer with optional discriminative learning rates."""
        
        if self.use_discriminative_lr:
            # Get layer groups
            layer_groups = DiscriminativeLearningRate.get_layer_groups(
                self.tl_model.model,
                'resnet' if 'resnet' in self.model_name else 'vgg'
            )
            
            # Create parameter groups with different learning rates
            param_groups = DiscriminativeLearningRate.create_param_groups(
                layer_groups,
                base_lr=base_lr / 10,
                lr_multiplier=2.6
            )
            
            optimizer = optim.Adam(param_groups)
            print("\n✓ Using discriminative learning rates")
        else:
            optimizer = optim.Adam(
                self.tl_model.model.parameters(),
                lr=base_lr
            )
            print("\n✓ Using uniform learning rate")
        
        return optimizer
    
    def train_with_techniques(
        self,
        train_loader: DataLoader,
        val_loader: DataLoader,
        num_epochs: int = 20,
        base_lr: float = 0.001,
        use_knowledge_distillation: bool = False,
        teacher_model: nn.Module = None
    ):
        """
        Training loop with all transfer learning techniques.
        
        Args:
            train_loader: Training data loader
            val_loader: Validation data loader
            num_epochs: Number of epochs
            base_lr: Base learning rate
            use_knowledge_distillation: Whether to use knowledge distillation
            teacher_model: Pre-trained teacher model for distillation
        """
        # Setup optimizer
        optimizer = self.setup_optimizer(base_lr)
        
        # Loss criterion
        criterion = nn.CrossEntropyLoss()
        
        # Learning rate scheduler
        scheduler = optim.lr_scheduler.CosineAnnealingLR(
            optimizer, T_max=num_epochs
        )
        
        history = {
            'train_loss': [],
            'val_loss': [],
            'train_acc': [],
            'val_acc': []
        }
        
        print(f"\nTraining Configuration:")
        print(f"- Model: {self.model_name}")
        print(f"- Epochs: {num_epochs}")
        print(f"- Base LR: {base_lr}")
        print(f"- Discriminative LR: {self.use_discriminative_lr}")
        print(f"- Gradual Unfreezing: {self.use_gradual_unfreezing}")
        print(f"- Domain Adaptation: {self.use_domain_adaptation}")
        print(f"- Knowledge Distillation: {use_knowledge_distillation}")
        print("-" * 60)
        
        for epoch in range(num_epochs):
            # Gradual unfreezing
            if self.use_gradual_unfreezing:
                self.unfreezing_scheduler.step(epoch)
            
            # Training phase
            train_loss, train_acc = self._train_epoch(
                train_loader,
                criterion,
                optimizer,
                use_knowledge_distillation,
                teacher_model
            )
            
            # Validation phase
            val_loss, val_acc = self._validate(val_loader, criterion)
            
            # Update scheduler
            scheduler.step()
            
            # Save history
            history['train_loss'].append(train_loss)
            history['train_acc'].append(train_acc)
            history['val_loss'].append(val_loss)
            history['val_acc'].append(val_acc)
            
            print(f"Epoch {epoch+1}/{num_epochs}")
            print(f"  Train Loss: {train_loss:.4f} | Train Acc: {train_acc:.4f}")
            print(f"  Val Loss: {val_loss:.4f} | Val Acc: {val_acc:.4f}")
            print(f"  LR: {optimizer.param_groups[-1]['lr']:.6f}")
        
        return history
    
    def _train_epoch(
        self,
        train_loader: DataLoader,
        criterion: nn.Module,
        optimizer: optim.Optimizer,
        use_kd: bool,
        teacher_model: nn.Module
    ):
        """Train for one epoch."""
        
        self.tl_model.model.train()
        total_loss = 0
        correct = 0
        total = 0
        
        for inputs, labels in train_loader:
            inputs = inputs.to(self.device)
            labels = labels.to(self.device)
            
            optimizer.zero_grad()
            
            # Forward pass
            outputs = self.tl_model.model(inputs)
            
            # Compute loss
            if use_kd and teacher_model is not None:
                # Knowledge distillation
                teacher_model.eval()
                with torch.no_grad():
                    teacher_outputs = teacher_model(inputs)
                
                loss = KnowledgeDistillation.combined_loss(
                    outputs,
                    teacher_outputs,
                    labels,
                    temperature=3.0,
                    alpha=0.5
                )
            else:
                # Standard cross-entropy
                loss = criterion(outputs, labels)
            
            # Domain adaptation loss (if applicable)
            if self.use_domain_adaptation:
                # Extract features (before final layer)
                features = self._extract_features(inputs)
                # In practice, you'd have target domain data
                # Here we use a placeholder
                domain_loss = 0.1 * features.std()  # Placeholder
                loss = loss + domain_loss
            
            # Backward pass
            loss.backward()
            optimizer.step()
            
            # Statistics
            total_loss += loss.item()
            _, predicted = outputs.max(1)
            total += labels.size(0)
            correct += predicted.eq(labels).sum().item()
        
        avg_loss = total_loss / len(train_loader)
        accuracy = correct / total
        
        return avg_loss, accuracy
    
    def _validate(self, val_loader: DataLoader, criterion: nn.Module):
        """Validate the model."""
        
        self.tl_model.model.eval()
        total_loss = 0
        correct = 0
        total = 0
        
        with torch.no_grad():
            for inputs, labels in val_loader:
                inputs = inputs.to(self.device)
                labels = labels.to(self.device)
                
                outputs = self.tl_model.model(inputs)
                loss = criterion(outputs, labels)
                
                total_loss += loss.item()
                _, predicted = outputs.max(1)
                total += labels.size(0)
                correct += predicted.eq(labels).sum().item()
        
        avg_loss = total_loss / len(val_loader)
        accuracy = correct / total
        
        return avg_loss, accuracy
    
    def _extract_features(self, inputs: torch.Tensor) -> torch.Tensor:
        """Extract features from model."""
        # Remove final layer
        feature_extractor = nn.Sequential(
            *list(self.tl_model.model.children())[:-1]
        )
        features = feature_extractor(inputs)
        return features.flatten(1)
    
    def plot_training_history(self, history: Dict[str, List[float]]):
        """Plot training curves."""
        
        fig, axes = plt.subplots(1, 2, figsize=(14, 5))
        
        # Loss
        axes[0].plot(history['train_loss'], label='Train Loss', marker='o')
        axes[0].plot(history['val_loss'], label='Val Loss', marker='s')
        axes[0].set_xlabel('Epoch')
        axes[0].set_ylabel('Loss')
        axes[0].set_title('Training and Validation Loss')
        axes[0].legend()
        axes[0].grid(True, alpha=0.3)
        
        # Accuracy
        axes[1].plot(history['train_acc'], label='Train Acc', marker='o')
        axes[1].plot(history['val_acc'], label='Val Acc', marker='s')
        axes[1].set_xlabel('Epoch')
        axes[1].set_ylabel('Accuracy')
        axes[1].set_title('Training and Validation Accuracy')
        axes[1].legend()
        axes[1].grid(True, alpha=0.3)
        
        plt.tight_layout()
        plt.savefig('/home/claude/training_history.png', dpi=300, bbox_inches='tight')
        print("\n✓ Training history plot saved to training_history.png")


def create_dummy_dataset(num_samples: int = 1000, num_classes: int = 10):
    """Create dummy dataset for demonstration."""
    
    # Random images (3 channels, 224x224)
    images = torch.randn(num_samples, 3, 224, 224)
    labels = torch.randint(0, num_classes, (num_samples,))
    
    # Split into train and validation
    split = int(0.8 * num_samples)
    
    train_dataset = TensorDataset(images[:split], labels[:split])
    val_dataset = TensorDataset(images[split:], labels[split:])
    
    train_loader = DataLoader(train_dataset, batch_size=32, shuffle=True)
    val_loader = DataLoader(val_dataset, batch_size=32, shuffle=False)
    
    return train_loader, val_loader


def demonstrate_lr_finder():
    """Demonstrate learning rate finder."""
    
    print("\n" + "=" * 60)
    print("Learning Rate Finder")
    print("=" * 60)
    
    # Create model and data
    model = TransferLearningModel('resnet50', num_classes=10, pretrained=True)
    train_loader, _ = create_dummy_dataset(200)
    
    criterion = nn.CrossEntropyLoss()
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    
    # Find optimal learning rate
    print("\nFinding optimal learning rate...")
    lrs, losses = learning_rate_finder(
        model.model,
        train_loader,
        criterion,
        device,
        start_lr=1e-7,
        end_lr=1,
        num_iter=50
    )
    
    # Plot
    plt.figure(figsize=(10, 6))
    plt.plot(lrs, losses)
    plt.xscale('log')
    plt.xlabel('Learning Rate')
    plt.ylabel('Loss')
    plt.title('Learning Rate Finder')
    plt.grid(True, alpha=0.3)
    plt.savefig('/home/claude/lr_finder.png', dpi=300, bbox_inches='tight')
    
    # Find optimal LR (steepest descent)
    gradients = np.gradient(losses)
    optimal_idx = np.argmin(gradients)
    optimal_lr = lrs[optimal_idx]
    
    print(f"\n✓ Suggested learning rate: {optimal_lr:.2e}")
    print("✓ LR finder plot saved to lr_finder.png")


def main():
    """Main demonstration."""
    
    print("=" * 60)
    print("Comprehensive Transfer Learning Demonstration")
    print("=" * 60)
    
    # Create datasets
    print("\nCreating dummy datasets...")
    train_loader, val_loader = create_dummy_dataset(num_samples=500)
    print(f"✓ Dataset created (500 samples)")
    
    # Strategy 1: Basic transfer learning
    print("\n" + "-" * 60)
    print("Strategy 1: Basic Transfer Learning")
    print("-" * 60)
    
    basic_model = ComprehensiveTransferLearning(
        model_name='resnet50',
        num_classes=10,
        use_discriminative_lr=False,
        use_gradual_unfreezing=False
    )
    
    history_basic = basic_model.train_with_techniques(
        train_loader, val_loader,
        num_epochs=3,
        base_lr=0.001
    )
    
    # Strategy 2: Advanced techniques
    print("\n" + "-" * 60)
    print("Strategy 2: Advanced Transfer Learning")
    print("-" * 60)
    
    advanced_model = ComprehensiveTransferLearning(
        model_name='resnet50',
        num_classes=10,
        use_discriminative_lr=True,
        use_gradual_unfreezing=True,
        use_domain_adaptation=False
    )
    
    history_advanced = advanced_model.train_with_techniques(
        train_loader, val_loader,
        num_epochs=3,
        base_lr=0.001
    )
    
    # Plot comparison
    print("\n" + "-" * 60)
    print("Plotting Results")
    print("-" * 60)
    
    advanced_model.plot_training_history(history_advanced)
    
    # Demonstrate LR finder
    demonstrate_lr_finder()
    
    print("\n" + "=" * 60)
    print("Demonstration Complete!")
    print("=" * 60)
    print("\nKey Takeaways:")
    print("1. Transfer learning accelerates convergence")
    print("2. Discriminative LRs improve fine-tuning")
    print("3. Gradual unfreezing prevents catastrophic forgetting")
    print("4. LR finder helps optimize learning rate")
    print("5. Domain adaptation aligns feature distributions")
    print("6. Knowledge distillation transfers knowledge efficiently")


if __name__ == "__main__":
    main()
