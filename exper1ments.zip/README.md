# Transfer Learning Implementation

A comprehensive implementation of transfer learning techniques for deep learning, including fine-tuning pre-trained models (VGG, ResNet, BERT) on domain-specific datasets.

## 📋 Overview

Transfer learning leverages knowledge learned from large datasets (like ImageNet or Wikipedia) and applies it to specific tasks with limited data. This implementation provides:

- **Computer Vision**: VGG16, ResNet50, ResNet101 for image classification
- **Natural Language Processing**: BERT for text classification and sentiment analysis
- **Advanced Techniques**: Discriminative learning rates, gradual unfreezing, domain adaptation, knowledge distillation

## 🎯 Key Features

### 1. Pre-trained Models
- **VGG16**: 16-layer deep convolutional network
- **ResNet50/101**: Residual networks with skip connections
- **BERT**: Bidirectional encoder representations from transformers

### 2. Fine-tuning Strategies
- Feature extraction (freeze base layers)
- Full fine-tuning (train all layers)
- Progressive fine-tuning (gradual unfreezing)
- Discriminative learning rates (different LR per layer)

### 3. Advanced Techniques
- **Domain Adaptation**: MMD, CORAL for distribution alignment
- **Multi-Task Learning**: Shared representations across tasks
- **Knowledge Distillation**: Teacher-student learning
- **Learning Rate Finder**: Optimal LR selection

## 📁 File Structure

```
transfer_learning_cv.py           # Computer vision transfer learning (VGG, ResNet)
transfer_learning_bert.py         # NLP transfer learning (BERT)
advanced_transfer_learning.py     # Advanced techniques and strategies
comprehensive_example.py          # Complete demonstration pipeline
README.md                         # This file
requirements.txt                  # Python dependencies
```

## 🚀 Quick Start

### Installation

```bash
pip install torch torchvision transformers numpy matplotlib tqdm
```

### Basic Usage - Computer Vision

```python
from transfer_learning_cv import TransferLearningModel

# Create model
model = TransferLearningModel(
    model_name='resnet50',
    num_classes=10,
    pretrained=True,
    freeze_base=False
)

# Get data transforms
transforms = model.get_data_transforms()

# Train
history = model.train(
    train_loader,
    val_loader,
    num_epochs=10,
    learning_rate=0.001
)

# Predict
pred_class, probabilities = model.predict(image_tensor)
```

### Basic Usage - NLP

```python
from transfer_learning_bert import BERTTransferLearning

# Create BERT model
model = BERTTransferLearning(
    model_name='bert-base-uncased',
    num_classes=2,
    max_length=128,
    freeze_bert=False
)

# Prepare data
train_loader, val_loader = model.prepare_data(
    texts, labels, batch_size=16
)

# Fine-tune
history = model.train(
    train_loader,
    val_loader,
    num_epochs=3,
    learning_rate=2e-5
)

# Predict
pred_class, probs = model.predict("This is a great product!")
```

## 🔧 Advanced Techniques

### 1. Discriminative Learning Rates

Different layers learn at different rates:

```python
from advanced_transfer_learning import DiscriminativeLearningRate

# Get layer groups
layer_groups = DiscriminativeLearningRate.get_layer_groups(
    model, 'resnet'
)

# Create parameter groups with different LRs
param_groups = DiscriminativeLearningRate.create_param_groups(
    layer_groups,
    base_lr=0.0001,
    lr_multiplier=2.6
)

optimizer = torch.optim.Adam(param_groups)
```

### 2. Gradual Unfreezing

Progressively unfreeze layers during training:

```python
from advanced_transfer_learning import GradualUnfreezing

unfreezer = GradualUnfreezing(model, total_epochs=20)

for epoch in range(num_epochs):
    unfreezer.step(epoch)  # Automatically unfreezes layers
    # ... training code ...
```

### 3. Learning Rate Finder

Find optimal learning rate automatically:

```python
from advanced_transfer_learning import learning_rate_finder

lrs, losses = learning_rate_finder(
    model, train_loader, criterion, device
)

# Plot and find optimal LR
optimal_lr = lrs[np.argmin(np.gradient(losses))]
```

### 4. Domain Adaptation

Align source and target distributions:

```python
from advanced_transfer_learning import DomainAdaptation

# Maximum Mean Discrepancy
mmd_loss = DomainAdaptation.maximum_mean_discrepancy(
    source_features, target_features
)

# CORAL loss
coral_loss = DomainAdaptation.coral_loss(
    source_features, target_features
)

total_loss = task_loss + 0.1 * mmd_loss
```

### 5. Knowledge Distillation

Transfer knowledge from large teacher to small student:

```python
from advanced_transfer_learning import KnowledgeDistillation

loss = KnowledgeDistillation.combined_loss(
    student_logits,
    teacher_logits,
    targets,
    temperature=3.0,
    alpha=0.5
)
```

## 📊 Training Strategies

### Strategy 1: Feature Extraction (Fastest)
```python
model = TransferLearningModel(
    model_name='resnet50',
    num_classes=10,
    freeze_base=True  # Freeze convolutional layers
)
# Only trains final classification layer
# Best for: Small datasets, similar domains
```

### Strategy 2: Full Fine-tuning (Most Flexible)
```python
model = TransferLearningModel(
    model_name='resnet50',
    num_classes=10,
    freeze_base=False  # Train all layers
)
# Trains entire network
# Best for: Large datasets, different domains
```

### Strategy 3: Progressive Fine-tuning (Recommended)
```python
# Start with frozen base
model = TransferLearningModel(freeze_base=True)

# Train classifier only
model.train(epochs=5)

# Unfreeze last N layers
model.unfreeze_layers(num_layers=10)

# Continue training
model.train(epochs=5)
```

## 🎓 Best Practices

### 1. Learning Rate Selection
- **Feature extraction**: Higher LR (0.001 - 0.01)
- **Fine-tuning base**: Lower LR (0.0001 - 0.001)
- **BERT fine-tuning**: Very low LR (1e-5 - 5e-5)

### 2. Data Augmentation
```python
transforms.Compose([
    transforms.RandomResizedCrop(224),
    transforms.RandomHorizontalFlip(),
    transforms.ColorJitter(brightness=0.2, contrast=0.2),
    transforms.ToTensor(),
    transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
])
```

### 3. Batch Size
- **Large models** (ResNet101, BERT-large): 8-16
- **Medium models** (ResNet50, BERT-base): 16-32
- **Small models** (VGG16): 32-64

### 4. Training Schedule
```
Epochs 1-3:   Train classifier only (frozen base)
Epochs 4-7:   Unfreeze last layer group
Epochs 8-10:  Unfreeze all layers (low LR)
```

## 📈 Performance Tips

### Accelerate Convergence
1. Use pre-trained weights
2. Apply discriminative learning rates
3. Implement learning rate warmup
4. Use batch normalization
5. Apply gradient clipping

### Prevent Overfitting
1. Use dropout (0.3 - 0.5)
2. Apply data augmentation
3. Implement early stopping
4. Use weight decay (1e-4)
5. Reduce model size if needed

### Improve Accuracy
1. Ensemble multiple models
2. Use test-time augmentation
3. Fine-tune longer
4. Try different architectures
5. Use larger input sizes

## 🔬 Example Use Cases

### 1. Medical Image Classification
```python
# X-ray classification: Normal vs Pneumonia
model = TransferLearningModel('resnet50', num_classes=2)
# Dataset: ~1000 images per class
# Strategy: Full fine-tuning with data augmentation
```

### 2. Sentiment Analysis
```python
# Product reviews: Positive/Negative
model = BERTTransferLearning('bert-base-uncased', num_classes=2)
# Dataset: ~5000 reviews
# Strategy: Fine-tune last 4 BERT layers
```

### 3. Custom Object Detection
```python
# Detecting specific products
model = TransferLearningModel('resnet101', num_classes=50)
# Dataset: ~100 images per class
# Strategy: Feature extraction + custom classifier
```

## 🧪 Running Examples

### Demo 1: Computer Vision
```bash
python transfer_learning_cv.py
```
Output:
- Trained ResNet50 model
- Validation accuracy
- Sample predictions

### Demo 2: NLP
```bash
python transfer_learning_bert.py
```
Output:
- Fine-tuned BERT model
- Sentiment predictions
- Feature embeddings

### Demo 3: Comprehensive Pipeline
```bash
python comprehensive_example.py
```
Output:
- Comparison of strategies
- Training curves
- Learning rate finder plot

## 📊 Expected Results

### Computer Vision (ImageNet → Custom Dataset)
| Strategy | Epochs | Accuracy | Training Time |
|----------|--------|----------|---------------|
| Feature Extraction | 5 | 85-90% | ~10 min |
| Full Fine-tuning | 10 | 90-95% | ~30 min |
| Progressive | 15 | 92-97% | ~40 min |

### NLP (BERT → Sentiment Analysis)
| Dataset Size | Epochs | Accuracy | Training Time |
|--------------|--------|----------|---------------|
| 1K samples | 3 | 85-88% | ~5 min |
| 10K samples | 3 | 92-94% | ~15 min |
| 100K samples | 3 | 95-97% | ~2 hours |

## 🐛 Troubleshooting

### Issue: Out of Memory
**Solution**: Reduce batch size, use gradient accumulation
```python
# Instead of batch_size=32
batch_size = 8
accumulation_steps = 4  # Effective batch size = 32
```

### Issue: Slow Convergence
**Solution**: Increase learning rate, use warmup
```python
warmup_steps = len(train_loader) // 10
scheduler = get_linear_schedule_with_warmup(optimizer, warmup_steps, total_steps)
```

### Issue: Overfitting
**Solution**: Add regularization, more augmentation
```python
dropout = 0.5
weight_decay = 1e-4
# Add stronger augmentation
```

### Issue: Poor Performance
**Solution**: Try different architectures, check data
```python
# Try ResNet101 instead of ResNet50
# Verify data labels and preprocessing
# Increase training epochs
```

## 📚 References

1. **VGG**: Simonyan & Zisserman (2014) - "Very Deep Convolutional Networks"
2. **ResNet**: He et al. (2015) - "Deep Residual Learning for Image Recognition"
3. **BERT**: Devlin et al. (2018) - "BERT: Pre-training of Deep Bidirectional Transformers"
4. **Transfer Learning**: Pan & Yang (2010) - "A Survey on Transfer Learning"
5. **Discriminative Fine-tuning**: Howard & Ruder (2018) - "Universal Language Model Fine-tuning"

## 📄 License

MIT License - Feel free to use for research and commercial applications.

## 🤝 Contributing

Contributions welcome! Areas for improvement:
- Additional pre-trained models (EfficientNet, Vision Transformer)
- More domain adaptation techniques
- Multi-modal transfer learning
- Automated hyperparameter tuning

## 📞 Support

For issues or questions:
1. Check the troubleshooting section
2. Review code comments and docstrings
3. Run demo scripts for examples
4. Refer to original paper implementations

---

**Happy Transfer Learning! 🚀**
