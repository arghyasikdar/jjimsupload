"""
Transfer Learning for Computer Vision
=====================================
Implements transfer learning using pre-trained models (VGG16, ResNet50)
for domain-specific image classification tasks.
"""

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, Dataset
from torchvision import models, transforms
from torchvision.datasets import ImageFolder
import numpy as np
from pathlib import Path
from typing import Tuple, Optional, Dict
import time
from tqdm import tqdm


class TransferLearningModel:
    """
    Transfer learning wrapper for pre-trained computer vision models.
    Supports fine-tuning strategies and feature extraction.
    """
    
    def __init__(
        self,
        model_name: str = 'resnet50',
        num_classes: int = 10,
        pretrained: bool = True,
        freeze_base: bool = False
    ):
        """
        Initialize transfer learning model.
        
        Args:
            model_name: Name of pre-trained model ('vgg16', 'resnet50', 'resnet101')
            num_classes: Number of classes in target dataset
            pretrained: Whether to use pre-trained weights
            freeze_base: Whether to freeze base model parameters
        """
        self.model_name = model_name
        self.num_classes = num_classes
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        
        # Load pre-trained model
        self.model = self._load_model(model_name, pretrained, num_classes)
        
        # Optionally freeze base layers
        if freeze_base:
            self._freeze_base_layers()
        
        self.model = self.model.to(self.device)
        
        # Training history
        self.history = {
            'train_loss': [],
            'train_acc': [],
            'val_loss': [],
            'val_acc': []
        }
    
    def _load_model(self, model_name: str, pretrained: bool, num_classes: int) -> nn.Module:
        """Load and modify pre-trained model."""
        
        if model_name == 'vgg16':
            model = models.vgg16(pretrained=pretrained)
            # Modify classifier
            num_features = model.classifier[6].in_features
            model.classifier[6] = nn.Linear(num_features, num_classes)
            
        elif model_name == 'resnet50':
            model = models.resnet50(pretrained=pretrained)
            # Modify final layer
            num_features = model.fc.in_features
            model.fc = nn.Linear(num_features, num_classes)
            
        elif model_name == 'resnet101':
            model = models.resnet101(pretrained=pretrained)
            num_features = model.fc.in_features
            model.fc = nn.Linear(num_features, num_classes)
            
        else:
            raise ValueError(f"Model {model_name} not supported")
        
        return model
    
    def _freeze_base_layers(self):
        """Freeze base model parameters for feature extraction."""
        
        if 'vgg' in self.model_name:
            # Freeze feature extractor
            for param in self.model.features.parameters():
                param.requires_grad = False
        
        elif 'resnet' in self.model_name:
            # Freeze all layers except final FC
            for name, param in self.model.named_parameters():
                if 'fc' not in name:
                    param.requires_grad = False
        
        print(f"Base layers frozen. Only training final layers.")
    
    def unfreeze_layers(self, num_layers: Optional[int] = None):
        """
        Unfreeze layers for fine-tuning.
        
        Args:
            num_layers: Number of layers to unfreeze from the end (None = all)
        """
        if num_layers is None:
            # Unfreeze all layers
            for param in self.model.parameters():
                param.requires_grad = True
            print("All layers unfrozen")
        else:
            # Unfreeze last N layers
            params = list(self.model.parameters())
            for param in params[-num_layers:]:
                param.requires_grad = True
            print(f"Last {num_layers} layers unfrozen")
    
    def get_data_transforms(self, input_size: int = 224) -> Dict[str, transforms.Compose]:
        """Get data augmentation transforms."""
        
        data_transforms = {
            'train': transforms.Compose([
                transforms.RandomResizedCrop(input_size),
                transforms.RandomHorizontalFlip(),
                transforms.RandomRotation(15),
                transforms.ColorJitter(brightness=0.2, contrast=0.2, saturation=0.2),
                transforms.ToTensor(),
                transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
            ]),
            'val': transforms.Compose([
                transforms.Resize(input_size + 32),
                transforms.CenterCrop(input_size),
                transforms.ToTensor(),
                transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
            ])
        }
        
        return data_transforms
    
    def train_epoch(
        self,
        train_loader: DataLoader,
        criterion: nn.Module,
        optimizer: optim.Optimizer
    ) -> Tuple[float, float]:
        """Train for one epoch."""
        
        self.model.train()
        running_loss = 0.0
        running_corrects = 0
        
        pbar = tqdm(train_loader, desc='Training')
        for inputs, labels in pbar:
            inputs = inputs.to(self.device)
            labels = labels.to(self.device)
            
            # Zero gradients
            optimizer.zero_grad()
            
            # Forward pass
            outputs = self.model(inputs)
            loss = criterion(outputs, labels)
            
            # Backward pass
            loss.backward()
            optimizer.step()
            
            # Statistics
            _, preds = torch.max(outputs, 1)
            running_loss += loss.item() * inputs.size(0)
            running_corrects += torch.sum(preds == labels.data)
            
            pbar.set_postfix({'loss': loss.item()})
        
        epoch_loss = running_loss / len(train_loader.dataset)
        epoch_acc = running_corrects.double() / len(train_loader.dataset)
        
        return epoch_loss, epoch_acc.item()
    
    def validate(
        self,
        val_loader: DataLoader,
        criterion: nn.Module
    ) -> Tuple[float, float]:
        """Validate the model."""
        
        self.model.eval()
        running_loss = 0.0
        running_corrects = 0
        
        with torch.no_grad():
            for inputs, labels in tqdm(val_loader, desc='Validation'):
                inputs = inputs.to(self.device)
                labels = labels.to(self.device)
                
                outputs = self.model(inputs)
                loss = criterion(outputs, labels)
                
                _, preds = torch.max(outputs, 1)
                running_loss += loss.item() * inputs.size(0)
                running_corrects += torch.sum(preds == labels.data)
        
        epoch_loss = running_loss / len(val_loader.dataset)
        epoch_acc = running_corrects.double() / len(val_loader.dataset)
        
        return epoch_loss, epoch_acc.item()
    
    def train(
        self,
        train_loader: DataLoader,
        val_loader: DataLoader,
        num_epochs: int = 10,
        learning_rate: float = 0.001,
        scheduler_type: str = 'step'
    ):
        """
        Full training loop with validation.
        
        Args:
            train_loader: Training data loader
            val_loader: Validation data loader
            num_epochs: Number of training epochs
            learning_rate: Initial learning rate
            scheduler_type: Learning rate scheduler ('step', 'plateau', 'cosine')
        """
        
        criterion = nn.CrossEntropyLoss()
        
        # Different learning rates for base and head
        if 'vgg' in self.model_name:
            params_to_update = [
                {'params': self.model.features.parameters(), 'lr': learning_rate * 0.1},
                {'params': self.model.classifier.parameters(), 'lr': learning_rate}
            ]
        else:  # ResNet
            params_to_update = [
                {'params': [p for n, p in self.model.named_parameters() if 'fc' not in n],
                 'lr': learning_rate * 0.1},
                {'params': self.model.fc.parameters(), 'lr': learning_rate}
            ]
        
        optimizer = optim.Adam(params_to_update)
        
        # Learning rate scheduler
        if scheduler_type == 'step':
            scheduler = optim.lr_scheduler.StepLR(optimizer, step_size=7, gamma=0.1)
        elif scheduler_type == 'plateau':
            scheduler = optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min', patience=3)
        elif scheduler_type == 'cosine':
            scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=num_epochs)
        
        best_acc = 0.0
        
        print(f"\nTraining {self.model_name} for {num_epochs} epochs")
        print(f"Device: {self.device}")
        print("-" * 60)
        
        for epoch in range(num_epochs):
            start_time = time.time()
            
            # Train
            train_loss, train_acc = self.train_epoch(train_loader, criterion, optimizer)
            
            # Validate
            val_loss, val_acc = self.validate(val_loader, criterion)
            
            # Update scheduler
            if scheduler_type == 'plateau':
                scheduler.step(val_loss)
            else:
                scheduler.step()
            
            # Save history
            self.history['train_loss'].append(train_loss)
            self.history['train_acc'].append(train_acc)
            self.history['val_loss'].append(val_loss)
            self.history['val_acc'].append(val_acc)
            
            epoch_time = time.time() - start_time
            
            print(f"\nEpoch {epoch+1}/{num_epochs} ({epoch_time:.1f}s)")
            print(f"Train Loss: {train_loss:.4f} | Train Acc: {train_acc:.4f}")
            print(f"Val Loss: {val_loss:.4f} | Val Acc: {val_acc:.4f}")
            
            # Save best model
            if val_acc > best_acc:
                best_acc = val_acc
                torch.save(self.model.state_dict(), 'best_model.pth')
                print(f"✓ New best model saved (acc: {best_acc:.4f})")
        
        print("\n" + "=" * 60)
        print(f"Training complete! Best validation accuracy: {best_acc:.4f}")
        
        return self.history
    
    def predict(self, image_tensor: torch.Tensor) -> Tuple[int, torch.Tensor]:
        """
        Predict class for a single image.
        
        Args:
            image_tensor: Preprocessed image tensor
            
        Returns:
            Predicted class index and probabilities
        """
        self.model.eval()
        
        with torch.no_grad():
            image_tensor = image_tensor.unsqueeze(0).to(self.device)
            outputs = self.model(image_tensor)
            probabilities = torch.softmax(outputs, dim=1)
            predicted_class = torch.argmax(probabilities, dim=1)
        
        return predicted_class.item(), probabilities.squeeze()
    
    def extract_features(self, image_tensor: torch.Tensor) -> np.ndarray:
        """
        Extract feature representations from pre-trained model.
        
        Args:
            image_tensor: Preprocessed image tensor
            
        Returns:
            Feature vector
        """
        self.model.eval()
        
        # Remove final classification layer
        if 'vgg' in self.model_name:
            feature_extractor = nn.Sequential(*list(self.model.children())[:-1])
        else:  # ResNet
            feature_extractor = nn.Sequential(*list(self.model.children())[:-1])
        
        with torch.no_grad():
            image_tensor = image_tensor.unsqueeze(0).to(self.device)
            features = feature_extractor(image_tensor)
            features = features.flatten()
        
        return features.cpu().numpy()


def demo_transfer_learning():
    """Demonstrate transfer learning with a sample dataset."""
    
    print("Transfer Learning Demo - Computer Vision")
    print("=" * 60)
    
    # Create model
    model = TransferLearningModel(
        model_name='resnet50',
        num_classes=10,
        pretrained=True,
        freeze_base=False
    )
    
    print(f"\nModel: {model.model_name}")
    print(f"Number of classes: {model.num_classes}")
    print(f"Total parameters: {sum(p.numel() for p in model.model.parameters()):,}")
    print(f"Trainable parameters: {sum(p.numel() for p in model.model.parameters() if p.requires_grad):,}")
    
    # Get data transforms
    transforms_dict = model.get_data_transforms()
    
    print("\nData augmentation configured:")
    print("- Random cropping and resizing")
    print("- Random horizontal flips")
    print("- Color jittering")
    print("- Normalization with ImageNet stats")
    
    # Example: Create dummy data for demonstration
    from torch.utils.data import TensorDataset
    
    dummy_images = torch.randn(100, 3, 224, 224)
    dummy_labels = torch.randint(0, 10, (100,))
    
    train_dataset = TensorDataset(dummy_images[:80], dummy_labels[:80])
    val_dataset = TensorDataset(dummy_images[80:], dummy_labels[80:])
    
    train_loader = DataLoader(train_dataset, batch_size=16, shuffle=True)
    val_loader = DataLoader(val_dataset, batch_size=16, shuffle=False)
    
    print(f"\nDataset created:")
    print(f"Training samples: {len(train_dataset)}")
    print(f"Validation samples: {len(val_dataset)}")
    
    # Train for a few epochs (demo)
    print("\nStarting training (demo with 2 epochs)...")
    history = model.train(
        train_loader,
        val_loader,
        num_epochs=2,
        learning_rate=0.001,
        scheduler_type='step'
    )
    
    # Test prediction
    print("\nTesting prediction on sample image...")
    test_image = dummy_images[0]
    pred_class, probabilities = model.predict(test_image)
    
    print(f"Predicted class: {pred_class}")
    print(f"Top 3 probabilities:")
    top_probs, top_indices = torch.topk(probabilities, 3)
    for i, (prob, idx) in enumerate(zip(top_probs, top_indices)):
        print(f"  {i+1}. Class {idx.item()}: {prob.item():.4f}")
    
    # Extract features
    print("\nExtracting features...")
    features = model.extract_features(test_image)
    print(f"Feature vector shape: {features.shape}")
    
    print("\n" + "=" * 60)
    print("Demo complete!")


if __name__ == "__main__":
    demo_transfer_learning()
