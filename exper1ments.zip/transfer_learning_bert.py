"""
Transfer Learning for NLP with BERT
===================================
Implements transfer learning using pre-trained BERT models
for domain-specific text classification, sentiment analysis, and NER tasks.
"""

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, Dataset
from transformers import (
    BertTokenizer, BertModel, BertForSequenceClassification,
    AdamW, get_linear_schedule_with_warmup
)
import numpy as np
from typing import List, Tuple, Dict, Optional
from tqdm import tqdm
import time


class TextDataset(Dataset):
    """Custom dataset for text classification."""
    
    def __init__(
        self,
        texts: List[str],
        labels: List[int],
        tokenizer: BertTokenizer,
        max_length: int = 128
    ):
        self.texts = texts
        self.labels = labels
        self.tokenizer = tokenizer
        self.max_length = max_length
    
    def __len__(self):
        return len(self.texts)
    
    def __getitem__(self, idx):
        text = str(self.texts[idx])
        label = self.labels[idx]
        
        encoding = self.tokenizer.encode_plus(
            text,
            add_special_tokens=True,
            max_length=self.max_length,
            padding='max_length',
            truncation=True,
            return_attention_mask=True,
            return_tensors='pt'
        )
        
        return {
            'input_ids': encoding['input_ids'].flatten(),
            'attention_mask': encoding['attention_mask'].flatten(),
            'label': torch.tensor(label, dtype=torch.long)
        }


class BERTTransferLearning:
    """
    Transfer learning wrapper for BERT-based text classification.
    Supports fine-tuning and feature extraction approaches.
    """
    
    def __init__(
        self,
        model_name: str = 'bert-base-uncased',
        num_classes: int = 2,
        max_length: int = 128,
        freeze_bert: bool = False,
        dropout: float = 0.3
    ):
        """
        Initialize BERT transfer learning model.
        
        Args:
            model_name: Pre-trained BERT model name
            num_classes: Number of output classes
            max_length: Maximum sequence length
            freeze_bert: Whether to freeze BERT layers
            dropout: Dropout rate for classifier
        """
        self.model_name = model_name
        self.num_classes = num_classes
        self.max_length = max_length
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        
        # Load tokenizer and model
        self.tokenizer = BertTokenizer.from_pretrained(model_name)
        self.model = self._build_model(model_name, num_classes, dropout)
        
        # Optionally freeze BERT
        if freeze_bert:
            self._freeze_bert_layers()
        
        self.model = self.model.to(self.device)
        
        # Training history
        self.history = {
            'train_loss': [],
            'train_acc': [],
            'val_loss': [],
            'val_acc': []
        }
    
    def _build_model(
        self,
        model_name: str,
        num_classes: int,
        dropout: float
    ) -> nn.Module:
        """Build BERT-based classification model."""
        
        # Use pre-trained BERT for sequence classification
        model = BertForSequenceClassification.from_pretrained(
            model_name,
            num_labels=num_classes,
            hidden_dropout_prob=dropout,
            attention_probs_dropout_prob=dropout
        )
        
        return model
    
    def _freeze_bert_layers(self):
        """Freeze BERT encoder layers for feature extraction."""
        
        # Freeze all BERT layers
        for param in self.model.bert.parameters():
            param.requires_grad = False
        
        print("BERT layers frozen. Only training classifier head.")
    
    def unfreeze_layers(self, num_layers: Optional[int] = None):
        """
        Gradually unfreeze BERT layers for fine-tuning.
        
        Args:
            num_layers: Number of encoder layers to unfreeze (None = all)
        """
        if num_layers is None:
            # Unfreeze all BERT layers
            for param in self.model.bert.parameters():
                param.requires_grad = True
            print("All BERT layers unfrozen")
        else:
            # Unfreeze last N encoder layers
            total_layers = len(self.model.bert.encoder.layer)
            layers_to_unfreeze = total_layers - num_layers
            
            for i, layer in enumerate(self.model.bert.encoder.layer):
                if i >= layers_to_unfreeze:
                    for param in layer.parameters():
                        param.requires_grad = True
            
            print(f"Last {num_layers} encoder layers unfrozen")
    
    def prepare_data(
        self,
        texts: List[str],
        labels: List[int],
        batch_size: int = 16,
        validation_split: float = 0.2
    ) -> Tuple[DataLoader, DataLoader]:
        """
        Prepare data loaders for training and validation.
        
        Args:
            texts: List of text samples
            labels: List of corresponding labels
            batch_size: Batch size for training
            validation_split: Fraction of data for validation
            
        Returns:
            Training and validation data loaders
        """
        # Split data
        split_idx = int(len(texts) * (1 - validation_split))
        
        train_texts = texts[:split_idx]
        train_labels = labels[:split_idx]
        val_texts = texts[split_idx:]
        val_labels = labels[split_idx:]
        
        # Create datasets
        train_dataset = TextDataset(
            train_texts, train_labels, self.tokenizer, self.max_length
        )
        val_dataset = TextDataset(
            val_texts, val_labels, self.tokenizer, self.max_length
        )
        
        # Create data loaders
        train_loader = DataLoader(
            train_dataset,
            batch_size=batch_size,
            shuffle=True
        )
        val_loader = DataLoader(
            val_dataset,
            batch_size=batch_size,
            shuffle=False
        )
        
        print(f"Training samples: {len(train_dataset)}")
        print(f"Validation samples: {len(val_dataset)}")
        
        return train_loader, val_loader
    
    def train_epoch(
        self,
        train_loader: DataLoader,
        optimizer: optim.Optimizer,
        scheduler: Optional[object] = None
    ) -> Tuple[float, float]:
        """Train for one epoch."""
        
        self.model.train()
        total_loss = 0
        correct_predictions = 0
        total_predictions = 0
        
        pbar = tqdm(train_loader, desc='Training')
        for batch in pbar:
            input_ids = batch['input_ids'].to(self.device)
            attention_mask = batch['attention_mask'].to(self.device)
            labels = batch['label'].to(self.device)
            
            # Forward pass
            outputs = self.model(
                input_ids=input_ids,
                attention_mask=attention_mask,
                labels=labels
            )
            
            loss = outputs.loss
            logits = outputs.logits
            
            # Backward pass
            optimizer.zero_grad()
            loss.backward()
            
            # Gradient clipping
            torch.nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=1.0)
            
            optimizer.step()
            
            if scheduler:
                scheduler.step()
            
            # Statistics
            total_loss += loss.item()
            predictions = torch.argmax(logits, dim=1)
            correct_predictions += (predictions == labels).sum().item()
            total_predictions += labels.size(0)
            
            pbar.set_postfix({'loss': loss.item()})
        
        avg_loss = total_loss / len(train_loader)
        accuracy = correct_predictions / total_predictions
        
        return avg_loss, accuracy
    
    def validate(self, val_loader: DataLoader) -> Tuple[float, float]:
        """Validate the model."""
        
        self.model.eval()
        total_loss = 0
        correct_predictions = 0
        total_predictions = 0
        
        with torch.no_grad():
            for batch in tqdm(val_loader, desc='Validation'):
                input_ids = batch['input_ids'].to(self.device)
                attention_mask = batch['attention_mask'].to(self.device)
                labels = batch['label'].to(self.device)
                
                outputs = self.model(
                    input_ids=input_ids,
                    attention_mask=attention_mask,
                    labels=labels
                )
                
                loss = outputs.loss
                logits = outputs.logits
                
                total_loss += loss.item()
                predictions = torch.argmax(logits, dim=1)
                correct_predictions += (predictions == labels).sum().item()
                total_predictions += labels.size(0)
        
        avg_loss = total_loss / len(val_loader)
        accuracy = correct_predictions / total_predictions
        
        return avg_loss, accuracy
    
    def train(
        self,
        train_loader: DataLoader,
        val_loader: DataLoader,
        num_epochs: int = 3,
        learning_rate: float = 2e-5,
        warmup_steps: int = 0
    ):
        """
        Full training loop with validation.
        
        Args:
            train_loader: Training data loader
            val_loader: Validation data loader
            num_epochs: Number of training epochs
            learning_rate: Learning rate
            warmup_steps: Number of warmup steps for scheduler
        """
        # Optimizer
        optimizer = AdamW(
            self.model.parameters(),
            lr=learning_rate,
            eps=1e-8
        )
        
        # Learning rate scheduler with warmup
        total_steps = len(train_loader) * num_epochs
        scheduler = get_linear_schedule_with_warmup(
            optimizer,
            num_warmup_steps=warmup_steps,
            num_training_steps=total_steps
        )
        
        best_acc = 0.0
        
        print(f"\nFine-tuning {self.model_name} for {num_epochs} epochs")
        print(f"Device: {self.device}")
        print("-" * 60)
        
        for epoch in range(num_epochs):
            start_time = time.time()
            
            # Train
            train_loss, train_acc = self.train_epoch(train_loader, optimizer, scheduler)
            
            # Validate
            val_loss, val_acc = self.validate(val_loader)
            
            # Save history
            self.history['train_loss'].append(train_loss)
            self.history['train_acc'].append(train_acc)
            self.history['val_loss'].append(val_loss)
            self.history['val_acc'].append(val_acc)
            
            epoch_time = time.time() - start_time
            
            print(f"\nEpoch {epoch+1}/{num_epochs} ({epoch_time:.1f}s)")
            print(f"Train Loss: {train_loss:.4f} | Train Acc: {train_acc:.4f}")
            print(f"Val Loss: {val_loss:.4f} | Val Acc: {val_acc:.4f}")
            
            # Save best model
            if val_acc > best_acc:
                best_acc = val_acc
                torch.save(self.model.state_dict(), 'best_bert_model.pth')
                print(f"✓ New best model saved (acc: {best_acc:.4f})")
        
        print("\n" + "=" * 60)
        print(f"Training complete! Best validation accuracy: {best_acc:.4f}")
        
        return self.history
    
    def predict(
        self,
        text: str,
        return_probabilities: bool = True
    ) -> Tuple[int, Optional[np.ndarray]]:
        """
        Predict class for a single text.
        
        Args:
            text: Input text
            return_probabilities: Whether to return class probabilities
            
        Returns:
            Predicted class and optionally probabilities
        """
        self.model.eval()
        
        encoding = self.tokenizer.encode_plus(
            text,
            add_special_tokens=True,
            max_length=self.max_length,
            padding='max_length',
            truncation=True,
            return_attention_mask=True,
            return_tensors='pt'
        )
        
        input_ids = encoding['input_ids'].to(self.device)
        attention_mask = encoding['attention_mask'].to(self.device)
        
        with torch.no_grad():
            outputs = self.model(
                input_ids=input_ids,
                attention_mask=attention_mask
            )
            logits = outputs.logits
            
        predicted_class = torch.argmax(logits, dim=1).item()
        
        if return_probabilities:
            probabilities = torch.softmax(logits, dim=1).cpu().numpy()[0]
            return predicted_class, probabilities
        
        return predicted_class, None
    
    def extract_embeddings(self, text: str) -> np.ndarray:
        """
        Extract BERT embeddings for a text.
        
        Args:
            text: Input text
            
        Returns:
            CLS token embedding (768-dim for BERT-base)
        """
        self.model.eval()
        
        encoding = self.tokenizer.encode_plus(
            text,
            add_special_tokens=True,
            max_length=self.max_length,
            padding='max_length',
            truncation=True,
            return_attention_mask=True,
            return_tensors='pt'
        )
        
        input_ids = encoding['input_ids'].to(self.device)
        attention_mask = encoding['attention_mask'].to(self.device)
        
        with torch.no_grad():
            # Get hidden states from BERT
            outputs = self.model.bert(
                input_ids=input_ids,
                attention_mask=attention_mask
            )
            
            # Use [CLS] token embedding
            cls_embedding = outputs.last_hidden_state[:, 0, :].cpu().numpy()
        
        return cls_embedding[0]


def demo_bert_transfer_learning():
    """Demonstrate BERT transfer learning."""
    
    print("Transfer Learning Demo - BERT for Text Classification")
    print("=" * 60)
    
    # Sample data (sentiment analysis)
    texts = [
        "This movie was absolutely fantastic! I loved every moment.",
        "Terrible experience, would not recommend to anyone.",
        "The product quality is excellent and shipping was fast.",
        "Worst customer service I've ever experienced.",
        "Highly recommend! Great value for money.",
        "Complete waste of time and money.",
        "Amazing! Exceeded all my expectations.",
        "Poor quality, very disappointed.",
        "Outstanding service and great product!",
        "Not worth the price, very underwhelming.",
    ] * 10  # Repeat for more samples
    
    labels = [1, 0, 1, 0, 1, 0, 1, 0, 1, 0] * 10  # 1=positive, 0=negative
    
    # Create model
    model = BERTTransferLearning(
        model_name='bert-base-uncased',
        num_classes=2,
        max_length=64,
        freeze_bert=False,
        dropout=0.3
    )
    
    print(f"\nModel: {model.model_name}")
    print(f"Number of classes: {model.num_classes}")
    print(f"Max sequence length: {model.max_length}")
    print(f"Total parameters: {sum(p.numel() for p in model.model.parameters()):,}")
    print(f"Trainable parameters: {sum(p.numel() for p in model.model.parameters() if p.requires_grad):,}")
    
    # Prepare data
    print("\nPreparing data...")
    train_loader, val_loader = model.prepare_data(
        texts, labels, batch_size=8, validation_split=0.2
    )
    
    # Train
    print("\nStarting fine-tuning (2 epochs for demo)...")
    history = model.train(
        train_loader,
        val_loader,
        num_epochs=2,
        learning_rate=2e-5,
        warmup_steps=10
    )
    
    # Test predictions
    print("\nTesting predictions...")
    test_texts = [
        "This is an excellent product, highly satisfied!",
        "Absolutely horrible, complete disaster."
    ]
    
    for text in test_texts:
        pred_class, probs = model.predict(text)
        sentiment = "Positive" if pred_class == 1 else "Negative"
        confidence = probs[pred_class] * 100
        
        print(f"\nText: {text}")
        print(f"Prediction: {sentiment} (confidence: {confidence:.2f}%)")
    
    # Extract embeddings
    print("\nExtracting BERT embeddings...")
    embedding = model.extract_embeddings(test_texts[0])
    print(f"Embedding shape: {embedding.shape}")
    print(f"First 10 values: {embedding[:10]}")
    
    print("\n" + "=" * 60)
    print("Demo complete!")


if __name__ == "__main__":
    demo_bert_transfer_learning()
