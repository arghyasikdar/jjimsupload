"""
Advanced Transfer Learning Strategies
=====================================
Implements advanced techniques including:
- Progressive fine-tuning
- Discriminative learning rates
- Gradual unfreezing
- Domain adaptation
- Multi-task learning
"""

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
import numpy as np
from typing import List, Dict, Tuple, Optional, Callable
from copy import deepcopy


class ProgressiveFinetuning:
    """
    Progressive fine-tuning strategy that gradually unfreezes layers.
    """
    
    def __init__(
        self,
        model: nn.Module,
        device: torch.device,
        unfreeze_schedule: List[int]
    ):
        """
        Args:
            model: Neural network model
            device: Torch device
            unfreeze_schedule: List of epochs at which to unfreeze layers
        """
        self.model = model
        self.device = device
        self.unfreeze_schedule = sorted(unfreeze_schedule)
        self.current_stage = 0
    
    def should_unfreeze(self, epoch: int) -> bool:
        """Check if layers should be unfrozen at current epoch."""
        if self.current_stage < len(self.unfreeze_schedule):
            if epoch >= self.unfreeze_schedule[self.current_stage]:
                self.current_stage += 1
                return True
        return False
    
    def unfreeze_next_layers(self, num_layers: int):
        """Unfreeze next N layers from the end."""
        params = list(self.model.parameters())
        for param in params[-num_layers:]:
            param.requires_grad = True
        
        print(f"Unfroze {num_layers} layers")


class DiscriminativeLearningRate:
    """
    Implements discriminative learning rates where different layers
    have different learning rates.
    """
    
    @staticmethod
    def get_layer_groups(model: nn.Module, model_type: str) -> List[List[nn.Parameter]]:
        """
        Group model parameters into layers for different learning rates.
        
        Args:
            model: Neural network model
            model_type: Type of model ('resnet', 'vgg', 'bert')
            
        Returns:
            List of parameter groups
        """
        if model_type == 'resnet':
            return [
                list(model.conv1.parameters()) + list(model.bn1.parameters()),
                list(model.layer1.parameters()),
                list(model.layer2.parameters()),
                list(model.layer3.parameters()),
                list(model.layer4.parameters()),
                list(model.fc.parameters())
            ]
        
        elif model_type == 'vgg':
            # Group by feature blocks
            groups = []
            current_group = []
            
            for module in model.features.children():
                current_group.extend(list(module.parameters()))
                if isinstance(module, nn.MaxPool2d):
                    groups.append(current_group)
                    current_group = []
            
            if current_group:
                groups.append(current_group)
            
            groups.append(list(model.classifier.parameters()))
            return groups
        
        elif model_type == 'bert':
            groups = []
            
            # Embeddings
            groups.append(list(model.bert.embeddings.parameters()))
            
            # Encoder layers
            for layer in model.bert.encoder.layer:
                groups.append(list(layer.parameters()))
            
            # Pooler
            groups.append(list(model.bert.pooler.parameters()))
            
            # Classifier
            groups.append(list(model.classifier.parameters()))
            
            return groups
        
        else:
            raise ValueError(f"Model type {model_type} not supported")
    
    @staticmethod
    def create_param_groups(
        layer_groups: List[List[nn.Parameter]],
        base_lr: float,
        lr_multiplier: float = 2.6
    ) -> List[Dict]:
        """
        Create parameter groups with discriminative learning rates.
        
        Args:
            layer_groups: List of parameter groups
            base_lr: Base learning rate for earliest layers
            lr_multiplier: Multiplier for learning rate increase per layer
            
        Returns:
            List of parameter group dictionaries
        """
        param_groups = []
        
        for i, group in enumerate(layer_groups):
            lr = base_lr * (lr_multiplier ** i)
            param_groups.append({
                'params': group,
                'lr': lr
            })
            print(f"Layer group {i}: lr = {lr:.2e}")
        
        return param_groups


class GradualUnfreezing:
    """
    Gradually unfreeze layers during training for better fine-tuning.
    """
    
    def __init__(
        self,
        model: nn.Module,
        total_epochs: int,
        unfreeze_epochs: Optional[List[int]] = None
    ):
        """
        Args:
            model: Neural network model
            total_epochs: Total training epochs
            unfreeze_epochs: Specific epochs to unfreeze (None = automatic)
        """
        self.model = model
        self.total_epochs = total_epochs
        
        # Auto-generate unfreeze schedule if not provided
        if unfreeze_epochs is None:
            # Unfreeze in 4 stages
            num_stages = 4
            self.unfreeze_epochs = [
                int(total_epochs * i / num_stages) 
                for i in range(1, num_stages + 1)
            ]
        else:
            self.unfreeze_epochs = unfreeze_epochs
        
        # Get all parameter groups
        self.param_groups = list(self._get_param_groups())
        self.current_stage = 0
        
        # Initially freeze all
        self._freeze_all()
    
    def _get_param_groups(self):
        """Get parameter groups from model."""
        for name, param in self.model.named_parameters():
            yield param
    
    def _freeze_all(self):
        """Freeze all parameters."""
        for param in self.model.parameters():
            param.requires_grad = False
    
    def step(self, epoch: int):
        """Update unfrozen layers based on current epoch."""
        for stage, unfreeze_epoch in enumerate(self.unfreeze_epochs):
            if epoch >= unfreeze_epoch and stage >= self.current_stage:
                self._unfreeze_stage(stage)
                self.current_stage = stage + 1
    
    def _unfreeze_stage(self, stage: int):
        """Unfreeze parameters for a specific stage."""
        total_groups = len(self.param_groups)
        groups_per_stage = total_groups // len(self.unfreeze_epochs)
        
        start_idx = stage * groups_per_stage
        end_idx = min(start_idx + groups_per_stage, total_groups)
        
        for i in range(start_idx, end_idx):
            self.param_groups[i].requires_grad = True
        
        print(f"Stage {stage}: Unfroze parameter groups {start_idx} to {end_idx}")


class DomainAdaptation:
    """
    Domain adaptation techniques for transfer learning.
    """
    
    @staticmethod
    def maximum_mean_discrepancy(
        source_features: torch.Tensor,
        target_features: torch.Tensor,
        kernel: str = 'rbf',
        sigma: float = 1.0
    ) -> torch.Tensor:
        """
        Compute Maximum Mean Discrepancy (MMD) between source and target domains.
        
        Args:
            source_features: Source domain features
            target_features: Target domain features
            kernel: Kernel type ('linear' or 'rbf')
            sigma: RBF kernel bandwidth
            
        Returns:
            MMD loss
        """
        if kernel == 'linear':
            return torch.mean(source_features, dim=0) - torch.mean(target_features, dim=0)
        
        elif kernel == 'rbf':
            # RBF kernel
            n_source = source_features.size(0)
            n_target = target_features.size(0)
            
            # Compute kernel matrices
            source_kernel = DomainAdaptation._rbf_kernel(source_features, source_features, sigma)
            target_kernel = DomainAdaptation._rbf_kernel(target_features, target_features, sigma)
            cross_kernel = DomainAdaptation._rbf_kernel(source_features, target_features, sigma)
            
            # MMD
            mmd = (torch.sum(source_kernel) / (n_source * n_source) +
                   torch.sum(target_kernel) / (n_target * n_target) -
                   2 * torch.sum(cross_kernel) / (n_source * n_target))
            
            return mmd
    
    @staticmethod
    def _rbf_kernel(x: torch.Tensor, y: torch.Tensor, sigma: float) -> torch.Tensor:
        """RBF kernel computation."""
        x_size = x.size(0)
        y_size = y.size(0)
        dim = x.size(1)
        
        x = x.unsqueeze(1).expand(x_size, y_size, dim)
        y = y.unsqueeze(0).expand(x_size, y_size, dim)
        
        return torch.exp(-torch.sum((x - y) ** 2, dim=2) / (2 * sigma ** 2))
    
    @staticmethod
    def coral_loss(source_features: torch.Tensor, target_features: torch.Tensor) -> torch.Tensor:
        """
        CORAL (Correlation Alignment) loss for domain adaptation.
        
        Args:
            source_features: Source domain features
            target_features: Target domain features
            
        Returns:
            CORAL loss
        """
        # Compute covariance matrices
        source_cov = DomainAdaptation._compute_covariance(source_features)
        target_cov = DomainAdaptation._compute_covariance(target_features)
        
        # Frobenius norm of difference
        loss = torch.sum((source_cov - target_cov) ** 2) / (4 * source_features.size(1) ** 2)
        
        return loss
    
    @staticmethod
    def _compute_covariance(features: torch.Tensor) -> torch.Tensor:
        """Compute covariance matrix."""
        n = features.size(0)
        features = features - torch.mean(features, dim=0)
        cov = torch.mm(features.t(), features) / (n - 1)
        return cov


class MultiTaskLearning:
    """
    Multi-task learning for transfer learning.
    """
    
    def __init__(
        self,
        shared_encoder: nn.Module,
        task_heads: Dict[str, nn.Module],
        task_weights: Optional[Dict[str, float]] = None
    ):
        """
        Args:
            shared_encoder: Shared feature encoder
            task_heads: Dictionary of task-specific heads
            task_weights: Optional weights for each task loss
        """
        self.shared_encoder = shared_encoder
        self.task_heads = task_heads
        
        # Default equal weights
        if task_weights is None:
            self.task_weights = {task: 1.0 for task in task_heads.keys()}
        else:
            self.task_weights = task_weights
    
    def forward(self, x: torch.Tensor) -> Dict[str, torch.Tensor]:
        """
        Forward pass through shared encoder and all task heads.
        
        Args:
            x: Input tensor
            
        Returns:
            Dictionary of task outputs
        """
        # Shared representation
        shared_features = self.shared_encoder(x)
        
        # Task-specific outputs
        outputs = {}
        for task_name, head in self.task_heads.items():
            outputs[task_name] = head(shared_features)
        
        return outputs
    
    def compute_loss(
        self,
        outputs: Dict[str, torch.Tensor],
        targets: Dict[str, torch.Tensor],
        criterions: Dict[str, nn.Module]
    ) -> Tuple[torch.Tensor, Dict[str, float]]:
        """
        Compute weighted multi-task loss.
        
        Args:
            outputs: Dictionary of task outputs
            targets: Dictionary of task targets
            criterions: Dictionary of loss functions per task
            
        Returns:
            Total loss and individual task losses
        """
        total_loss = 0
        task_losses = {}
        
        for task_name in outputs.keys():
            task_loss = criterions[task_name](outputs[task_name], targets[task_name])
            weighted_loss = self.task_weights[task_name] * task_loss
            
            total_loss += weighted_loss
            task_losses[task_name] = task_loss.item()
        
        return total_loss, task_losses


class KnowledgeDistillation:
    """
    Knowledge distillation for model compression and transfer learning.
    """
    
    @staticmethod
    def distillation_loss(
        student_logits: torch.Tensor,
        teacher_logits: torch.Tensor,
        temperature: float = 3.0
    ) -> torch.Tensor:
        """
        Compute knowledge distillation loss.
        
        Args:
            student_logits: Student model logits
            teacher_logits: Teacher model logits
            temperature: Softening temperature
            
        Returns:
            Distillation loss
        """
        # Soften probabilities
        soft_student = torch.softmax(student_logits / temperature, dim=1)
        soft_teacher = torch.softmax(teacher_logits / temperature, dim=1)
        
        # KL divergence
        loss = nn.KLDivLoss(reduction='batchmean')(
            torch.log(soft_student),
            soft_teacher
        ) * (temperature ** 2)
        
        return loss
    
    @staticmethod
    def combined_loss(
        student_logits: torch.Tensor,
        teacher_logits: torch.Tensor,
        targets: torch.Tensor,
        temperature: float = 3.0,
        alpha: float = 0.5
    ) -> torch.Tensor:
        """
        Combine distillation loss with standard cross-entropy.
        
        Args:
            student_logits: Student model logits
            teacher_logits: Teacher model logits
            targets: Ground truth labels
            temperature: Softening temperature
            alpha: Weight for distillation loss (1-alpha for CE loss)
            
        Returns:
            Combined loss
        """
        # Distillation loss
        distill_loss = KnowledgeDistillation.distillation_loss(
            student_logits, teacher_logits, temperature
        )
        
        # Standard cross-entropy
        ce_loss = nn.CrossEntropyLoss()(student_logits, targets)
        
        # Combined
        loss = alpha * distill_loss + (1 - alpha) * ce_loss
        
        return loss


def learning_rate_finder(
    model: nn.Module,
    train_loader: DataLoader,
    criterion: nn.Module,
    device: torch.device,
    start_lr: float = 1e-7,
    end_lr: float = 10,
    num_iter: int = 100
) -> Tuple[List[float], List[float]]:
    """
    Find optimal learning rate using learning rate range test.
    
    Args:
        model: Neural network model
        train_loader: Training data loader
        criterion: Loss criterion
        device: Torch device
        start_lr: Starting learning rate
        end_lr: Ending learning rate
        num_iter: Number of iterations
        
    Returns:
        Learning rates and corresponding losses
    """
    model.train()
    
    # Save original model state
    original_state = deepcopy(model.state_dict())
    
    optimizer = optim.SGD(model.parameters(), lr=start_lr)
    lr_scheduler = optim.lr_scheduler.ExponentialLR(
        optimizer,
        gamma=(end_lr / start_lr) ** (1 / num_iter)
    )
    
    lrs = []
    losses = []
    
    iterator = iter(train_loader)
    
    for i in range(num_iter):
        try:
            inputs, labels = next(iterator)
        except StopIteration:
            iterator = iter(train_loader)
            inputs, labels = next(iterator)
        
        inputs = inputs.to(device)
        labels = labels.to(device)
        
        # Forward pass
        optimizer.zero_grad()
        outputs = model(inputs)
        loss = criterion(outputs, labels)
        
        # Backward pass
        loss.backward()
        optimizer.step()
        
        # Record
        lrs.append(optimizer.param_groups[0]['lr'])
        losses.append(loss.item())
        
        # Update learning rate
        lr_scheduler.step()
        
        # Stop if loss explodes
        if i > 0 and losses[-1] > 4 * min(losses):
            break
    
    # Restore original model state
    model.load_state_dict(original_state)
    
    return lrs, losses


if __name__ == "__main__":
    print("Advanced Transfer Learning Strategies")
    print("=" * 60)
    print("\nThis module provides:")
    print("1. Progressive Fine-tuning")
    print("2. Discriminative Learning Rates")
    print("3. Gradual Unfreezing")
    print("4. Domain Adaptation (MMD, CORAL)")
    print("5. Multi-Task Learning")
    print("6. Knowledge Distillation")
    print("7. Learning Rate Finder")
    print("\nImport and use these classes in your training pipeline.")
